﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace Jeda_BPatcher
{
    public class SHex : IDisposable
    {
        public byte[] FileToPatch;
        public FileInfo FileInfo;

        public SHex()
        {

        }

        public SHex(FileInfo fileInfo)
        {
            FileInfo = fileInfo;
            FileToPatch = File.ReadAllBytes(fileInfo.FullName);
        }

        public void LoadFile()
        {
            FileToPatch = File.ReadAllBytes(FileInfo.FullName);
        }

        public void Save()
        {
            if (FileToPatch == null || FileInfo.Length == 0)
                throw new Exception("Selected File is null");
            else
            {
                File.WriteAllBytes(FileInfo.FullName.ToLower().Replace(".vir" , "") , FileToPatch);
            }
        }

        private static byte question = (byte)'?';
        public long FindPattern(string szPattern , out long lTime)
        {
            if (FileToPatch == null || FileInfo.Length == 0)
                throw new Exception("Selected File is null");

            Stopwatch stopwatch = Stopwatch.StartNew();

            byte[] arrPattern = ParsePatternString(szPattern);

            for (int nModuleIndex = 0; nModuleIndex < FileToPatch.Length; nModuleIndex++)
            {
                if (this.FileToPatch[nModuleIndex] != arrPattern[0])
                    continue;

                if (PatternCheck(nModuleIndex , arrPattern))
                {
                    lTime = stopwatch.ElapsedMilliseconds;
                    return (long)nModuleIndex;
                }
            }

            lTime = stopwatch.ElapsedMilliseconds;
            return 0;
        }
        private bool PatternCheck(int nOffset , byte[] arrPattern)
        {
            for (int i = 0; i < arrPattern.Length; i++)
            {
                if (arrPattern[i] == question)
                    continue;

                if (arrPattern[i] != this.FileToPatch[nOffset + i])
                    return false;
            }

            return true;
        }
        private byte[] ParsePatternString(string pattern)
        {
            if (string.IsNullOrWhiteSpace(pattern))
            {
                throw new ArgumentNullException("pattern");
            }

            List<byte> patternsBytes = new List<byte>(pattern.Length);

            List<string> patternsStrings = pattern.Split(' ').ToList();
            patternsStrings.RemoveAll(str => str == "");

            foreach (string str in patternsStrings)
            {
                if (str == "?")
                {
                    patternsBytes.Add(0);
                }
                else
                {
                    patternsBytes.Add(Convert.ToByte(str , 16));
                }
            }

            return patternsBytes.ToArray();
        }

        public void Dispose()
        {
            FileToPatch = null;
            GC.Collect();
        }
    }
}
