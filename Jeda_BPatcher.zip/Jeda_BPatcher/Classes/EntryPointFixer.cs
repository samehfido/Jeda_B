﻿using System;
using System.Collections.Generic;
using System.IO;
using PeNet;
using PeNet.Header.Pe;

namespace PESharp
{
    public class EntryPointFixer
    {
        private readonly Context context;
        public EntryPointFixer(Context _context)
        {
            context = _context;
        }

        public void Execute()
        {
            var shit = context.peFile.GetSectionByName("�");
            if (shit != null)
            {
                uint Entry = GetOriginalEntry(shit.PointerToRawData + 0x65);
                var rva = shit.VirtualAddress + 0x26D + 4 + Entry;//saved original ep 0x44 0x225 + 4

                ImageSectionHeader found = default(ImageSectionHeader);
                if (rva > 0)
                {
                    if (context.peFile.lookForFileOffset(rva , out found))
                        context.log($"EntryPoint found in {found.Name}");

                    context.log($"Old EntryPoint: 0x{context.peFile.ImageNtHeaders.OptionalHeader.AddressOfEntryPoint:x}");
                    context.log($"New EntryPoint: 0x{rva:x}");

                    context.peFile.ImageNtHeaders.OptionalHeader.AddressOfEntryPoint = rva;
                }
                else
                {
                    context.log($"error wrong EntryPoint \nOriginalEntry: 0x{Entry:x}");
                    context.log($"error wrong rva \nEntry: 0x{rva:x}");

                    //if (found?.Name != null && found.Name.Length > 0)
                    //    context.log($"HEADER Name: {found?.Name}");
                    //else context.log("HEADER Name: <null>");
                }
            }
            else
            {
                context.log("error section not found!");
            }
        }

        public uint GetOriginalEntry(uint offset)
        {
            uint Entry = 0;
            using (var input = new FileStream(context.filePath , FileMode.Open , FileAccess.Read))
            {
                input.Seek(offset , SeekOrigin.Begin);

                var b = new BinaryReader(input);
                {
                    byte[] savedEntry = b.ReadBytes(sizeof(int));
                    Entry = BitConverter.ToUInt32(savedEntry , 0);
                }
                context.log($"Original Entry Rva 0x{Entry:x}");
            }
            return Entry;
        }
    }
}
