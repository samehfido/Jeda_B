﻿using PeNet;
using PeNet.Header.Pe;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace PESharp
{
    public class SectionRemover
    {
        private readonly Context context;
        public SectionRemover(Context _context)
        {
            context = _context;
        }

        public void Execute()
        {
            string SectionName = context.peFile.GetSectionByName("�")?.Name;

            if (SectionName == null)
                return;

            context.log($"Removing the {SectionName} section...");

            // Remove rsrc from section headers
            RemoveSection(SectionName);

            // Save the changed binary to disk
            //File.WriteAllBytes(context.filePath , peFile.RawFile.ToArray());
        }

        /// <summary>
        /// Remove a section from the PE file.
        /// </summary>
        /// <param name="name">Name of the section to remove.</param>
        /// <param name="removeContent">Flag if the content should be removed or only the section header entry.</param>
        public void RemoveSection(string name , bool removeContent = true , bool FixAlignment = false)
        {
            var sectionToRemove = context.peFile.ImageSectionHeaders.First(s => s.Name == name);

            // Remove section from list of sections
            var newSections =  context.peFile.ImageSectionHeaders.Where(s => s.Name != name).ToArray();

            // Change number of sections in the file header
            context.peFile.ImageNtHeaders.FileHeader.NumberOfSections = (ushort)(context.peFile.ImageNtHeaders.FileHeader.NumberOfSections - 1);

            if (removeContent)
            {
                // Reloc the physical address of all sections
                foreach (var s in newSections)
                {
                    if (s.PointerToRawData > sectionToRemove.PointerToRawData)
                    {
                        s.PointerToRawData -= sectionToRemove.SizeOfRawData;
                    }
                }

                // Remove section content
                context.peFile.RawFile.RemoveRange(sectionToRemove.PointerToRawData , sectionToRemove.SizeOfRawData);
            }

            /*
             The VirtualSize and SizeOfRawData can be aligned to the FileAlignment and SectionAlignment 
             but it is optional as the Windows loader accepts not aligned sizes as well, so we skip this step.
             */

            if (FixAlignment)
            {
                // Fix virtual size
                for (var i = 1; i < newSections.Count(); i++)
                {
                    if (newSections[i - 1].VirtualAddress < sectionToRemove.VirtualAddress)
                    {
                        newSections[i - 1].VirtualSize = newSections[i].VirtualAddress - newSections[i - 1].VirtualAddress;
                    }
                }
            }

            // Replace old section headers with new section headers
            var sectionHeaderOffset = context.peFile.ImageDosHeader.E_lfanew + context.peFile.ImageNtHeaders.FileHeader.SizeOfOptionalHeader + 0x18;
            var sizeOfSection = 0x28;
            var newRawSections = new byte[newSections.Count() * sizeOfSection];
            for (var i = 0; i < newSections.Count(); i++)
            {
                Array.Copy(newSections[i].ToArray() , 0 , newRawSections , i * sizeOfSection , sizeOfSection);
            }

            // Null the data directory entry if any available
            var de = context.peFile.ImageNtHeaders
                .OptionalHeader
                .DataDirectory
                .FirstOrDefault(d => d.VirtualAddress == sectionToRemove.VirtualAddress
                    && d.Size == sectionToRemove.VirtualSize);

            if (de != null)
            {
                de.Size = 0;
                de.VirtualAddress = 0;
            }

            if (sectionToRemove.Characteristics.HasFlag( ScnCharacteristicsType.CntCode))
                context.peFile.ImageNtHeaders.OptionalHeader.SizeOfCode -= sectionToRemove.VirtualSize;

            context.peFile.ImageNtHeaders.OptionalHeader.SizeOfImage -= sectionToRemove.SizeOfRawData;//getNewSizeOfImage();


            // Null the old section headers
            context.peFile.RawFile.WriteBytes(sectionHeaderOffset , new byte[context.peFile.ImageSectionHeaders.Count() * sizeOfSection]);

            // Write the new sections headers
            context.peFile.RawFile.WriteBytes(sectionHeaderOffset , newRawSections);
        }

        uint getNewSizeOfImage(int size)
        {
            var factor = size / (double)context.peFile.ImageNtHeaders.OptionalHeader.SectionAlignment;
            var additionalSize = (uint)Math.Ceiling(factor) * context.peFile.ImageNtHeaders.OptionalHeader.SectionAlignment;
            return context.peFile.ImageNtHeaders.OptionalHeader.SizeOfImage + additionalSize;
        }

        //309 = (x / 0x1000) * 0x1000
        uint GetNewRawSecSize(ImageNtHeaders ImageNtHeaders , int unalignedSize)
        {
            return (uint)(Math.Ceiling((double)unalignedSize / (double)ImageNtHeaders.OptionalHeader.FileAlignment)
                * (double)ImageNtHeaders.OptionalHeader.FileAlignment);
        }

        uint getNewSecVA()
        {
            var lastSec = context.peFile.ImageSectionHeaders.OrderByDescending(sh => sh.VirtualAddress).First();
            var vaLastSecEnd = lastSec.VirtualAddress + lastSec.VirtualSize;
            var factor = vaLastSecEnd / (double)context.peFile.ImageNtHeaders.OptionalHeader.SectionAlignment;
            return (uint)(Math.Ceiling(factor) * context.peFile.ImageNtHeaders.OptionalHeader.SectionAlignment);
        }
    }

    //https://secanablog.wordpress.com/2020/04/12/how-to-remove-a-section-from-a-pe-file
    /*
     * From a high level view we need to do these things:

    Adjust NumberOfSections in the IMAGE_FILE_HEADER
    Remove the section from the IMAGE_SECTION_HEADER array
    Remove the content of the section from the PE file
    Adjust the physical addresses of the remaining sections in the IMAGE_SECTION_HEADER array
    Adjust the virtual size of the remaining sections in the IMAGE_SECTION_HEADER array
    Adjust the corresponding entry in the IMAGE_DATA_DIRECTORY array (if any)
    */

}
