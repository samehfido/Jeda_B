﻿using System.IO;
using System.Text;
using System;
using PeNet;
using System.Diagnostics;
using PeNet.Header.Pe;

namespace PESharp
{
    public class Context : IDisposable
    {
        public string filePath;
        private readonly StringBuilder sb;

        public PeFile peFile { get; set; }
        public Context(string _filePath)
        {
            filePath = _filePath;
            sb = new StringBuilder();
        }

        public bool LoadPE()
        {
            try
            {
                peFile = new PeFile(filePath);
                return peFile != null;
            }
            catch
            {
                return false;
            }
        }

        public void Backup()
        {
            if (!File.Exists(filePath + ".infected"))
                File.Copy(filePath , filePath + ".infected");
        }

        public void Save()
        {
            // Size is computed like this
            // Save the changed binary to disk
            File.WriteAllBytes(filePath , peFile.RawFile.ToArray());
            //write log
            File.WriteAllText(filePath + ".txt" , sb.ToString());
        }

        public void log(string message)
        {
            sb.AppendLine(message);
        }
        public void log(string message , params object[] args)
        {
            sb.AppendFormat(message , args);
        }

        public void Dispose()
        {
            peFile = null;
        }
    }
}
