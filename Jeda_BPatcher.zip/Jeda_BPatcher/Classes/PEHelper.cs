﻿using PeNet;
using PeNet.Header.Pe;
using System.Diagnostics;

namespace PESharp
{
    public static class PEHelper
    {
        public static ImageSectionHeader GetSectionByName(this PeFile peFile , string name)
        {
            var  SECTION = default(ImageSectionHeader);
            var headers = peFile.ImageNtHeaders;
            for (int i = 0; i < headers.FileHeader.NumberOfSections; i++)
            {
                string sname = peFile.ImageSectionHeaders[i].Name;

                if ( sname.Contains(name))//"�O�k�u�"
                {
                    SECTION = peFile.ImageSectionHeaders[i];
                    Trace.WriteLine($"Offset : 0x{SECTION.PointerToRawData + 0x65:x}");
                    return SECTION;
                }
            }
            return SECTION;
        }

        public static bool lookForFileOffset(this PeFile peFile , uint uRva , out ImageSectionHeader foundIn)
        {
            foundIn = default(ImageSectionHeader);
            var headers = peFile.ImageNtHeaders;
            for (int i = 0; i < headers.FileHeader.NumberOfSections; i++)
            {
                if (uRva >= peFile.ImageSectionHeaders[i].PointerToRawData
                    && (uRva < (peFile.ImageSectionHeaders[i].PointerToRawData + peFile.ImageSectionHeaders[i].SizeOfRawData)))
                {
                    //found
                    foundIn = peFile.ImageSectionHeaders[i];
                    return true;
                }
            }
            return false;
        }
    }

}
