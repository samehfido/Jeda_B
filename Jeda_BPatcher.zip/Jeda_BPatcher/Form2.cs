﻿using PESharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jeda_BPatcher
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
        }

        void addToList(FileInfo file , bool clean)
        {
            string index = $"{lvFiles.Items.Count + 1}";
            ListViewItem item = new ListViewItem(index);
            item.SubItems.Add(file.FullName);
            item.ImageIndex = clean ? 0 : 1; //wright 1 means wrong
            lvFiles.Items.Add(item);
        }

        private void SplitContainer1_DragDrop(object sender , DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            foreach (string file in files)
            {
                Console.WriteLine(file);
                if (File.Exists(file))
                    LoadAndFixFile(file);
                else
                    MessageBox.Show("Invalid File!");
            }
        }
        private void SplitContainer1_DragEnter(object sender , DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy;
        }

        void LoadAndFixFile(string file)
        {
            using (Context con = new Context(file))
            {
                if (LoadAndFixFile(new FileInfo(file)))
                    con.log("Binary Patched!");

                if (chk1.Checked)
                    con.Backup();

                if (con.LoadPE())
                {
                    if (chkFixEntry.Checked)
                        new EntryPointFixer(con).Execute();

                    if (chkRemoveSection.Checked)
                        new SectionRemover(con).Execute();

                    con.Save();
                }
            }
        }

        bool LoadAndFixFile(FileInfo fileInfo)
        {
            this.Text = fileInfo.FullName;
            var SHex = new SHex(fileInfo);

            var address = SHex.FindPattern("FF FF 50 FF 55 F0 8B F0", out long time);

            if (address > 0)
            {
                Trace.WriteLine($"Patcher >> Found address {address.ToString("X")} In {time} Milliseconds");
                PrepareFile(fileInfo);
                patchFile(address , SHex.FileToPatch , fileInfo);
            }
            else
            {
                MessageBox.Show("Not Found File Clean!");
                return false;
            }
            //patch jz C0 - DA
            var address2 = SHex.FindPattern("39 4D DC 74 1E 39 4D F0 74 19 39 4D EC 74 14 39 4D F8 74 0F 39 4D F4 74 0A 39 4D  E0 74 05 39 4D E8 75 0E", out time);
            if (address2 > 0)
            {
                Trace.WriteLine($"Patcher >> Found address {address2.ToString("X")} In {time} Milliseconds");
                byte[] PatchJZ = new byte[]
                    {
                            0x39, 0x4D, 0xDC, 0x90, 0x90, 0x39, 0x4D, 0xF0, 0x90, 0x90, 0x39, 0x4D, 0xEC, 0x90, 0x90, 0x39,
                            0x4D, 0xF8, 0x90, 0x90, 0x39, 0x4D, 0xF4, 0x90, 0x90, 0x39, 0x4D, 0xE0, 0x90, 0x90, 0x39, 0x4D,
                            0xE8, 0x74, 0x0E
                    };

                patchFile(address2 , PatchJZ , SHex.FileToPatch , fileInfo);
            }
            //patch call F4 - 0A
            var address3 = SHex.FindPattern("50 68 04 01  00 00 FF 55 E0 8D 45 B8 50 8D 85 94 FE FF FF 50  FF 55 E8", out time);
            if (address3 > 0)
            {
                Trace.WriteLine($"Patcher >> Found address {address3.ToString("X")} In {time} Milliseconds");
                byte[] PatchCall = new byte[]
                    {
                        0x50, 0x68, 0x04, 0x01, 0x00, 0x00, 0x90, 0x90, 0x90, 0x8D, 0x45, 0xB8, 0x50, 0x8D, 0x85, 0x94,
                        0xFE, 0xFF, 0xFF, 0x50, 0x90, 0x90, 0x90
                    };

                patchFile(address3 , PatchCall , SHex.FileToPatch , fileInfo);
            }

            //patch call 50 - 64
            var address4 = SHex.FindPattern("50 56 FF 55 EC 56 FF 55  F8 6A 05 8D 85 94 FE FF FF 50 FF 55 F4", out time);
            if (address4 > 0)
            {
                Trace.WriteLine($"Patcher >> Found address {address4.ToString("X")} In {time} Milliseconds");
                byte[] PatchCall = new byte[]
                   {
                        0x50, 0x56, 0x90, 0x90, 0x90, 0x56, 0x90, 0x90, 0x90, 0x6A, 0x05, 0x8D, 0x85, 0x94, 0xFE, 0xFF,
                        0xFF, 0x50, 0x90, 0x90, 0x90
                   };

                patchFile(address4 , PatchCall , SHex.FileToPatch , fileInfo);
            }

            SHex.Save();
            return true;
        }

        void patchFile(long Address , byte[] file , FileInfo fileInfo)
        {
            if (file.Length > 0)
            {
                byte[] PatchedBytes = new byte[] { 0xFF, 0xFF, 0x50, 0x90, 0x90, 0x90, 0x8B, 0xF0 };
                patchFile(Address , PatchedBytes , file , fileInfo);
            }
        }

        void patchFile(long Address , byte[] pattern , byte[] file , FileInfo fileInfo)
        {
            if (file.Length > 0)
            {
                Array.Copy(pattern , 0 , file , Address , pattern.Length);
            }
        }
        /// <summary>
        /// File Delete
        /// </summary>
        /// <param name="fileInfo"></param>
        void ReplaceFile(FileInfo fileInfo)
        {
            try
            {
                File.Delete(fileInfo.FullName);
            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// move or backup
        /// </summary>
        /// <param name="fileInfo"></param>
        void PrepareFile(FileInfo fileInfo)
        {
            if (chk1.Checked)
                File.Move(fileInfo.FullName , fileInfo.FullName + ".infected");
            else
            {
                ReplaceFile(fileInfo);
            }

        }

        #region Scanner
        private void button1_Click(object sender , EventArgs e)
        {
            FileFolderDialog dd = new FileFolderDialog();
            if (dd.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = dd.SelectedPath;
            }
        }

        IEnumerable<String> GetAllFiles(string path , string searchPattern)
        {
            return System.IO.Directory.EnumerateFiles(path , searchPattern).Union(
                System.IO.Directory.EnumerateDirectories(path).SelectMany(d =>
                {
                    try
                    {
                        return GetAllFiles(d , searchPattern);
                    }
                    catch (UnauthorizedAccessException e)
                    {
                        return Enumerable.Empty<String>();
                    }
                }));
        }

        private static void AddFiles(string path , IList<string> files)
        {
            try
            {
                var set = new HashSet<string> { ".exe", ".vir", "*.bak" };
                Directory.GetFiles(path , "*.*")
                    .Where(f => set.Contains(new FileInfo(f).Extension , StringComparer.OrdinalIgnoreCase))
                    .ToList()
                    .ForEach(s => files.Add(s));

                Directory.GetDirectories(path)
                    .ToList()
                    .ForEach(s => AddFiles(s , files));
            }
            catch (UnauthorizedAccessException ex)
            {
                Trace.WriteLine($"Error Access denied ->> {ex.Message}");
                // ok, so we are not allowed to dig into that directory. Move on.
            }
        }

        private void button2_Click(object sender , EventArgs e)
        {
            lvFiles.Items.Clear();
            if (textBox1.Text.Length > 0)
            {
                scanBar.Value = 0;
                string path = textBox1.Text;
                txtStatus.Text = "Preparing files..";

                Task.Factory.StartNew(() =>
                {
                    scanAll(path);
                }).Wait();

                txtStatus.Text = "Done!";
            }
        }

        void scanAll(string path)
        {
            var files = new List<string>();
            AddFiles(path , files);
            if (files.Count > 0)
                scanFiles(files);
        }

        void scanFiles(List<string> files)
        {
            scanBar.Maximum = files.Count;
            foreach (var file in files)
            {
                scanBar.PerformStep();
                txtStatus.Text = $"File: {file}";
                txtProgress.Text = $"Scaned : {scanBar.Value}/{scanBar.Maximum}";
                Application.DoEvents();

                var fileInfo = new FileInfo(file);
                if (fileInfo.Length > 1024 * 1024 * 25 || fileInfo.Length <= 1024)
                    continue;

                if (scan(file))//pattern scan
                {
                    addToList(fileInfo , false);
                    if (chkOpenLoc.Checked)
                    {
                        helper.OpenLocation(file);
                        break;
                    }
                }
                //addToList(fileInfo , true);
            }
            MessageBox.Show($"Found {lvFiles.Items.Count}" , "Scan Finished!");
        }


        bool scan(FileInfo file)
        {
            return scan(new SHex(file));
        }
        bool scan(string file)
        {
            return scan(new SHex(new FileInfo(file)));
        }

        bool scan(SHex SHex)
        {
            try
            {
                var address = SHex.FindPattern("FF FF 50 FF 55 F0 8B F0", out long time);
                if (address > 0)
                {
                    return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }


        #endregion

        private void openLocationToolStripMenuItem_Click(object sender , EventArgs e)
        {
            if (lvFiles.SelectedItems.Count == 1)
                helper.OpenLocation(lvFiles.SelectedItems[0].SubItems[1].Text);
        }

        private void btnFix_Click(object sender , EventArgs e)
        {
            if (lvFiles.Items.Count > 0)
            {
                foreach (ListViewItem item in lvFiles.Items)
                {
                    if (File.Exists(item.SubItems[1].Text))
                    {
                        LoadAndFixFile(item.SubItems[1].Text);
                        item.ImageIndex = 0;
                    }
                }
            }
        }
    }

}
