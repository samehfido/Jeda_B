﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Jeda_BPatcher
{
    class helper
    {
        public static bool NotificationIsShown = false;

        public static bool IsProcessRunning(string procName , out int ProcessId)
        {
            var process = Process.GetProcessesByName(procName).FirstOrDefault();
            if (process != null)
            {
                ProcessId = process.Id;
                return true;
            }
            ProcessId = 0;
            return false;
        }
        public static bool IsProcessRunning(string procName)
        {
            var process = Process.GetProcessesByName(procName).FirstOrDefault();
            if (process != null)
            {
                return true;
            }
            return false;
        }
        public static void OpenLocation(string filePath)
        {
            new Process
            {
                StartInfo =
                {
                    FileName = "explorer.exe",
                    Arguments = "/select,\"" + filePath + "\""
                }
            }.Start();
        }

        public static void OpenFolderLocation(string filePath)
        {
            new Process
            {
                StartInfo =
                {
                    FileName = "explorer.exe",
                    Arguments = "\"" + filePath + "\""
                }
            }.Start();
        }

        /// <summary>
        /// WaitNSeconds
        /// </summary>
        /// <param name="seconds"></param>
        public static void Delay(int seconds)
        {
            if (seconds < 1) return;
            DateTime _desired = DateTime.Now.AddSeconds(seconds);
            while (DateTime.Now < _desired)
            {
                Thread.Sleep(10);
                System.Windows.Forms.Application.DoEvents();
            }
        }

        /// <summary>
        /// WaitNSeconds
        /// </summary>
        /// <param name="Milliseconds"></param>
        public static void DelayM(int Milliseconds)
        {
            if (Milliseconds < 1) return;
            DateTime _desired = DateTime.Now.AddMilliseconds(Milliseconds);
            while (DateTime.Now < _desired)
            {
                Thread.Sleep(10);
                System.Windows.Forms.Application.DoEvents();
            }
        }
    }
    public class file
    {
        public string Name { get; set; }
        public string Path { get; set; }
        public int ProcessId { get; set; }
        public bool ProcessRunning { get; set; }
    }
}
