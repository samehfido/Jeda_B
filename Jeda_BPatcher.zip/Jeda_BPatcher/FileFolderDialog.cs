﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

public class FileFolderDialog : CommonDialog
{
    private OpenFileDialog m_dialog = new OpenFileDialog();

    public OpenFileDialog Dialog
    {
        get
        {
            return m_dialog;
        }
        set
        {
            m_dialog = value;
        }
    }

    public new DialogResult ShowDialog()
    {
        return this.ShowDialog(null);
    }

    public new DialogResult ShowDialog(IWin32Window owner)
    {
        // Set validate names to false otherwise windows will not let you select "Folder Selection."
        m_dialog.ValidateNames = false;
        m_dialog.CheckFileExists = false;
        m_dialog.CheckPathExists = true;
        m_dialog.Multiselect = FolderMultiselect;

        try
        {
            // Set initial directory (used when dialog.FileName is set from outside)
            if (m_dialog.FileName != null && !string.IsNullOrEmpty(m_dialog.FileName))
            {
                if (Directory.Exists(m_dialog.FileName))
                {
                    m_dialog.InitialDirectory = m_dialog.FileName;
                }
                else
                {
                    m_dialog.InitialDirectory = Path.GetDirectoryName(m_dialog.FileName);
                }
            }
            // Do nothing
        }
        catch 
        {
        }

        // Always default to Folder Selection.
        m_dialog.FileName = "Folder Selection.";

        if (owner == null)
        {
            return m_dialog.ShowDialog();
        }
        else
        {
            return m_dialog.ShowDialog(owner);
        }
    }

    /// <summary>
    /// Can select more than one dir
    /// </summary>
    public bool FolderMultiselect = false;

    //'
    // Helper property. Parses FilePath into either folder path (if Folder Selection. is set)
    // or returns file path
    //'
    public string SelectedPath
    {
        get
        {
            try
            {
                if (m_dialog.FileName != null && (m_dialog.FileName.EndsWith("Folder Selection.") || !File.Exists(m_dialog.FileName)) && !Directory.Exists(m_dialog.FileName))
                {
                    return Path.GetDirectoryName(m_dialog.FileName);
                }
                else
                {
                    return m_dialog.FileName;
                }
            }
            catch
            {
                return m_dialog.FileName;
            }
        }
        set
        {
            if (value != null && !string.IsNullOrEmpty(value))
            {
                m_dialog.FileName = value;
            }
        }
    }

    /// <summary>
    /// When multiple files are selected returns them as semi-colon seprated string
    /// Return null if selected paths only 1
    /// </summary>
    public string SelectedPaths
    {
        get
        {
            if (m_dialog.FileNames != null && m_dialog.FileNames.Length > 1)
            {
                StringBuilder sb = new StringBuilder();
                foreach (string fileName in m_dialog.FileNames)
                {
                    try
                    {
                        if (File.Exists(fileName))
                        {
                            sb.Append(fileName + ";");
                        }
                        // Go to next
                    }
                    catch
                    {
                    }
                }
                return sb.ToString();
            }
            else
            {
                return null;
            }
        }
    }

    public override void Reset()
    {
        m_dialog.Reset();
    }

    protected override bool RunDialog(IntPtr hwndOwner)
    {
        return true;
    }
}
